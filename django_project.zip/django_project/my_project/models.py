from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

# Create your models here.

class CategoryModel(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=20)
    created_at = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.title


class PostModel(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=20)
    content = models.TextField(default=None)
    image = models.ImageField(default=None)
    category = models.ForeignKey(CategoryModel, on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.title
    
class classModel(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=20)
    name = models.CharField(max_length=20)
    image = models.ImageField(default=None)
    # student = models.ForeignKey(StudentModel, on_delete=models.CASCADE)
    price = models.IntegerField(default=None)
    category = models.ForeignKey(CategoryModel, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.title
    
class StudentModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    parent = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    birthday = models.DateField()
    phone = models.IntegerField()
    address = models.TextField(default=None)

    def __str__(self):
        return self.name
    
class attendModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    email = models.EmailField(max_length=254)
    class_name = models.ForeignKey(classModel, on_delete=models.CASCADE)
    address = models.TextField(null=True)

    def __str__(self):
        return self.name