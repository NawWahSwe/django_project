from django.shortcuts import render
from my_project.models import *
from django.shortcuts import redirect
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password

# Create your views here.

def PostHome(request):
    return render(request, 'home.html')


def PostList(request):
    if request.GET.get('search'):
        search = request.GET.get('search')
        posts = PostModel.objects.filter(
            Q(title__icontains=search) |
            Q(content__icontains=search)
        )
        return render(request,'PostList.html', {'posts':posts}) 
    if request.GET.get('category'):
        category = request.GET.get('category')
        posts = PostModel.objects.filter(category_id=category)
        return render(request, 'PostList.html', {'posts':posts})
    
    posts = PostModel.objects.all()
    return render(request,'PostList.html',{'posts':posts})

def PostCreate(request):
    if request.method == "GET":
        category = CategoryModel.objects.all()
        return render(request, 'postcreate.html',{'category':category})
    if request.method == "POST":
        posts = PostModel.objects.create(
            title = request.POST.get('title'),
            content = request.POST.get('content'),
            image = request.FILES.get('image'),
            category_id = request.POST.get('category'),
            author_id = request.user.id
        )
        return redirect('/post/list/')
    
def PostDelete(request,post_id):
    post = PostModel.objects.get(id=post_id)
    post.delete()
    return redirect('/post/list/')


def PostClass(request):
    if request.GET.get('search'):
        search = request.GET.get('search')
        posts = classModel.objects.filter(
            Q(title__icontains=search) |
            Q(name__icontains=search)
        )
        return render(request,'class.html', {'posts':posts}) 
    posts = classModel.objects.all()
    return render(request, 'class.html', {'posts':posts})

def CreateClass(request):
    if request.method == "GET":
        category = CategoryModel.objects.all()
        return render(request, 'createclass.html' ,{'category':category})
    if request.method == "POST":
        posts = classModel.objects.create(
            title = request.POST.get('title'),
            name = request.POST.get('name'),
            image = request.FILES.get('image'),
            price = request.POST.get('price'),
            category_id = request.POST.get('category')
        )
        return redirect('/post/class/')
    
def DeleteClass(request,post_id):
    post = classModel.objects.get(id=post_id)
    post.delete()
    return redirect('/post/class/')

def PostEnroll(request):
    return render(request, 'enroll.html')

def PostAttend(request):
    posts = attendModel.objects.all()
    return render(request, 'attendlist.html',{'posts':posts})

def Postform(request):
    if request.method == "GET":
        class_name = classModel.objects.all()
        return render(request, 'form.html',{'class_name':class_name})
    if request.method == "POST":
        posts = attendModel.objects.create(
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            class_name_id = request.POST.get('class_name'),
            address = request.POST.get('address')
        )
        return redirect('/post/attendlist/')

def PostStudent(request):
    if request.GET.get('search'):
        search = request.GET.get('search')
        posts = StudentModel.objects.filter(
            Q(id__icontains=search) |
            Q(name__icontains=search)
        )
        return render(request,'studentlist.html', {'posts':posts}) 
    posts = StudentModel.objects.all()
    return render(request, 'studentlist.html',{'posts':posts})

def PostAdd(request):
    if request.method == "GET":
        return render (request, 'addstudent.html')
    if request.method == "POST":
        posts = StudentModel.objects.create(
            name = request.POST.get('name'),
            parent = request.POST.get('parent'),
            email = request.POST.get('email'),
            birthday = request.POST.get('birthday'),
            phone = request.POST.get('phone'),
            address = request.POST.get('address')
        )
        return redirect('/post/student/')
    
def DeleteStudent(request,post_id):
    post = StudentModel.objects.get(id=post_id)
    post.delete()
    return redirect('/post/student/')


def PostContact(request):
    return render(request, 'contact.html')

def myLogin(request):
    if request.method == "GET":
        return render (request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            # messages.warning(request, f"Welcome {user.username} Successfully")
            return redirect('/post/home/')
        else:
            # messages.error(request, "Username or password is incorrect!")
            return redirect('/login')
        
def myRegister(request):
    if request.method == "GET":
        return render(request, 'register.html')
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        try:
            Username = User.objects.get(username=username)
            # messages.error(request, 'Username already exits')
            return redirect('/register')
        except Exception:
            pass

        try:
            Useremail = User.objects.get(email=email)
            # messages.error(request, 'Email already exits')
            return redirect('/register')
        except Exception:
            pass
        
        user = User.objects.create(
            username = username,
            email = email,
            password = make_password(request.POST.get('password'))
        )
        # messages.error(request, 'Register Successfully')
        login(request, user)
        return redirect('/post/home/')
    
def myLogout(request):
    logout(request)
    return redirect ('/post/home/') 
