from django.urls import path
from my_project.views import *

urlpatterns=[
    path('list/',PostList),
    path('home/',PostHome),
    path('class/',PostClass),
    path('enroll/',PostEnroll),
    path('form/',Postform),
    path('contact/',PostContact),
    path('student/',PostStudent),
    path('addstudent/',PostAdd),
    path('create/',PostCreate),
    path('createclass/',CreateClass),
    path('delete/<int:post_id>/',PostDelete),
    path('deleteclass/<int:post_id>/',DeleteClass),
    path('deletestudent/<int:post_id>/',DeleteStudent),
    path('attendlist/',PostAttend)
]