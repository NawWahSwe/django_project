from django.contrib import admin
from my_project.models import *

# Register your models here.
class PostAdmin(admin.ModelAdmin):
    list_display = ['id','title','content','image','author','category','created_at']
    list_filter =['created_at']
    search_fields = ['title','content']
    
admin.site.register(PostModel)
admin.site.register(CategoryModel)
admin.site.register(classModel)
admin.site.register(StudentModel)
admin.site.register(attendModel)